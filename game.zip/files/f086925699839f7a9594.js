function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;
    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }
    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }
          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }
        return n[i].exports;
      }
      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) o(t[i]);
      return o;
    }
    return r;
  }()({
    1: [function (require, module, exports) {
      function main() {
        var scene = new g.Scene({
          game: g.game,
          assetPaths: ["/image/btn.png", "/audio/se", "/audio/se1", "/fonts/*", "/image/spbtn.png"] //シーン内で利用するアセットのファイルパス
        });
        g.game.vars.gameState = {
          score: 0
        }; //スコアの初期化
        var time = 60; // 制限時間
        scene.onLoad.add(function () {
          // const backgroundRect = new g.FilledRect({
          //   scene: scene,
          //   width: g.game.width,
          //   height: g.game.height,
          //   cssColor: "blue"
          // });
          // scene.append(backgroundRect);

          // for(i = 0; i < 5; i++)
          // {
          //   const rect = createRect(scene);
          //   scene.append(rect);
          // }

          var sprite = new g.Sprite({
            scene: scene,
            src: scene.asset.getImage("/image/btn.png"),
            scaleX: 0.1,
            //サイズを変更
            scaleY: 0.1,
            x: 300,
            y: 200
          });
          var spbtn = new g.Sprite({
            scene: scene,
            src: scene.asset.getImage("/image/spbtn.png"),
            scaleX: 0.1,
            //サイズを変更
            scaleY: 0.1,
            x: 300,
            y: 200
          });
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: "sans-serif",
            size: 15
          });

          // スコア表示エンティティの作成
          var scoreLabel = new g.Label({
            scene: scene,
            font: font,
            fontSize: font.size,
            text: "".concat(g.game.vars.gameState.score),
            x: g.game.width - 10,
            y: 10,
            anchorX: 1.0,
            anchorY: 0
          });
          scene.append(scoreLabel);

          // スコア表示を更新する
          function updateScoreLabel() {
            scoreLabel.text = "".concat(g.game.vars.gameState.score);
            scoreLabel.invalidate();
          }
          var remainingTime = time;
          // タイマー表示エンティティの作成
          var timerLabel = new g.Label({
            scene: scene,
            font: font,
            text: "".concat(remainingTime),
            fontSize: 15,
            textColor: "blue",
            x: 70,
            y: 10,
            width: 70,
            anchorX: 1.0,
            anchorY: 0
          });
          scene.append(timerLabel);

          // タイマー表示を更新する
          function updateTimer() {
            timerLabel.text = "".concat(remainingTime);
            timerLabel.invalidate();
          }
          sprite.touchable = true; //クリックの処理有効

          // クリックされた時の処理
          sprite.onPointDown.add(function () {
            console.log("Click");
            scene.asset.getAudio("/audio/se").play();
            // スコアを 10 点加算する例
            g.game.vars.gameState.score += 10;
            updateScoreLabel();
            // 位置をランダムに更新
            sprite.x = Math.floor(g.game.random.generate() * 500);
            sprite.y = Math.floor(g.game.random.generate() * 200);
            // 更新する
            sprite.modified();
            var rand = g.game.random.generate() * 50;
            if (rand < 20) {
              console.log("スペシャルボタンを生成");
              scene.append(spbtn);
            }
          });
          spbtn.touchable = true; //SPクリックの処理有効
          spbtn.onPointDown.add(function () {
            console.log("SPボタンが押されたよ！");
            //SPボタンのSEを鳴らす
            scene.asset.getAudio("/audio/se1").play();
            //1万ポイントを加算
            g.game.vars.gameState.score += 10000;
            updateScoreLabel();
            scene.remove(spbtn); // シーンから削除する
          });
          scene.append(sprite);

          // 残り時間の更新
          var timer = scene.setInterval(function () {
            remainingTime--;
            updateTimer();
          }, 1000);
        });
        g.game.pushScene(scene);
      }
      function createRect(scene) {
        return new g.FilledRect({
          scene: scene,
          x: Math.floor(g.game.localRandom.generate() * 320),
          y: 50,
          width: 50,
          height: 50,
          cssColor: "#7F3F3F"
        });
      }
      module.exports = main;
    }, {}]
  }, {}, [1])(1);
});